﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Text;

namespace BancoSocket
{
    class Tarjeta
    {
        
        public Tarjeta()
        {

        }
        
        public String ValidarTarjeta(String tarjeta,String cvv, String fecha,String monto, Conexion conexion)
        {

            String result = null;
            String data=conexion.ConsultaTarjeta(tarjeta);
            if (data==null)
            {
                result = null;
            }
            else
            {
                string[] words = data.Split('|');
                // TARJETA,CUENTA,SALDO,CVV,FECHA,EST
                String tar = words[0];
                String cuenta = words[1];
                String saldo = words[2];
                String ccv = words[3];
                String expi = words[4];
                String est = words[5];
                if (tarjeta == tar && ccv == cvv && expi == fecha && est == "ACT")
                {
                    result = "OK|" + data+"|"+monto;
                }
                else
                {
                    result = null;
                }
            }
           

            return result;
        }

        public String ConsultaCuenta(String validacion, Conexion conexion)
        {
            String result = null;
            String[] datosTarjeta = validacion.Split("|");
            // CUENTA,SALDO_DISPONIBLE,SALDO_REAL,SALDO_BLOQUEADO
            String cuenta = datosTarjeta[0];
            Double saldoDisponible = Convert.ToDouble(datosTarjeta[1]);
            Double saldoReal = Convert.ToDouble(datosTarjeta[2]);
            Double saldoBloqueado = Convert.ToDouble(datosTarjeta[3]);
            Double monto= Convert.ToDouble(datosTarjeta[4]); ;
            //String[] data=mensaje.Split("|");

            if (monto>saldoDisponible)
            {
                result = null;
            }
            else
            {
                result = "OKA";
            }
            

            return result;
        }
    }
}
